#include <bits/stdc++.h>
#include <ctime>
#include <stdlib.h>
/*
_______________________
|                      |
|  Powered By Yarik25  |
|______________________|
*/
using namespace std;
int main()
{
  cout << "Enter count of pictures: ";
  int height;
  cin >> height;
  int cadr;
  cout << "Count of animations: ";
  cin >> cadr;
  vector <string> line;
  for(int o = 0; o < cadr; o++)
  {
    cout << "Animation number: " << o+1 << endl;
    for(int i = 0; i < height; i++)
    {
      string add;
      cout << i << ": ";
      getline(cin, add);
      line.push_back(add);
    }
    cout << endl;
  }
  for(int i = 0; i < line.size(); i++)
  {
    cout << line[i ] << endl;
  }
  char con;
  cout << "Please, enter different symbol to start animation: ";
  time_t start;
  time(&start);
  int i = 0;
  while(start)
  {
    i++;
    cout << line[i] << endl;
    system("clear");
    if(i == height * cadr - 1)
    {
      i = 0;
    }
  }
  cin >> con;
  
  return 0;
}